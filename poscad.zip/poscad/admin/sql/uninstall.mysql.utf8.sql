DROP TABLE IF EXISTS `#__disciplina`;
DROP TABLE IF EXISTS `#__curso`;